#nullable enable
using System;
using UnityEngine;
using UnityEditor;
using UniGLTF;
using static Esperecyan.Unity.VRMConverterForVRChat.Utilities.Gettext;

namespace Esperecyan.Unity.VRMConverterForVRChat.UI
{
    /// <summary>
    /// 結果ダイアログ。
    /// </summary>
    internal class ErrorDialog : ScriptableWizard
    {
        private static readonly string IssuesURL = "https://github.com/esperecyan/VRMConverterForVRChat/issues";
        private static readonly string VRChatSDKVersionFilePath = "Assets/VRCSDK/version.txt";

        private string version = null!;
        private Exception exception = null!;
        private Vector2 errorMessageScrollPosition;

        private ErrorDialog()
        {
        }

        /// <summary>
        /// ダイアログを開きます。
        /// </summary>
        /// <param name="version">当エディタ拡張のバージョン。</param>
        /// <param name="messages"></param>
        internal static void Open(string version, Exception exception)
        {
            var dialog = ScriptableWizard.DisplayWizard<ErrorDialog>(
                title: Converter.Name + " " + version,
                createButtonName: _("Close")
            );
            dialog.version = version;
            dialog.exception = exception;
        }

        protected override bool DrawWizardGUI()
        {
            var errorMessage = this.exception.ToString() + "\n" + this.exception.StackTrace;

            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Label(_("Some error has occurred."));

                if (GUILayout.Button(_("Copy the content to clipboard")))
                {
                    var text = $"Unity Editor: {Application.unityVersion}\n";
                    var sdkVersion = AssetDatabase.LoadAssetAtPath<TextAsset>(ErrorDialog.VRChatSDKVersionFilePath);
                    if (sdkVersion != null)
                    {
                        text += $"VRChat SDK: {sdkVersion.text}\n";
                    }
                    text += $"{Converter.Name}: {this.version}\n"
                        + $"UniVRM: {PackageVersion.VERSION}\n\n"
                        + errorMessage;
                    GUIUtility.systemCopyBuffer = text;
                }

                if (GUILayout.Button(_("Report the problem")))
                {
                    Application.OpenURL(ErrorDialog.IssuesURL);
                }
            }

            using (var scope = new EditorGUILayout.ScrollViewScope(this.errorMessageScrollPosition, GUI.skin.box))
            {
                this.errorMessageScrollPosition = scope.scrollPosition;
                GUILayout.TextArea(errorMessage);
            }

            return true;
        }
    }
}
